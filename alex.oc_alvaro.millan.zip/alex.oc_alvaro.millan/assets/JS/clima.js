document.addEventListener("DOMContentLoaded", function () {
  let weatherForm = document.getElementById("weatherForm");
  let cityInput = document.getElementById("cityInput");
  let weatherFeedback = document.getElementById("weatherFeedback");

  let currentWeatherDiv = document.getElementById("currentWeather");
  let forecastWeatherDiv = document.getElementById("forecastWeather");

  // Clave de la API de OpenWeather
  let apiKey = "7060778325684b0a94454f5c0cebcceb";

  // Limpia resultados y mensajes anteriores
  function clearResults() {
    if (currentWeatherDiv) {
      currentWeatherDiv.innerHTML = "";
    }
    if (forecastWeatherDiv) {
      forecastWeatherDiv.innerHTML = "";
    }
    if (weatherFeedback) {
      weatherFeedback.textContent = "";
      weatherFeedback.className = "";
    }
  }

  // Muestra el clima actual
  function showCurrentWeather(data) {
    if (!currentWeatherDiv) return;

    currentWeatherDiv.innerHTML = "";

    let cityName = data.name;
    let temp = data.main && data.main.temp ? data.main.temp : "";
    let description =
      data.weather && data.weather[0] ? data.weather[0].description : "";
    let iconCode = data.weather && data.weather[0] ? data.weather[0].icon : "";
    let date = new Date(data.dt * 1000);

    let title = document.createElement("h3");
    title.className = "center";
    title.textContent = cityName;
    currentWeatherDiv.appendChild(title);

    let dateP = document.createElement("p");
    dateP.textContent = "Data: " + date.toLocaleString();
    currentWeatherDiv.appendChild(dateP);

    let infoP = document.createElement("p");
    infoP.textContent = "Temperatura: " + temp + " °C";
    currentWeatherDiv.appendChild(infoP);

    let descP = document.createElement("p");
    descP.textContent = "Estat del cel: " + description;
    currentWeatherDiv.appendChild(descP);

    if (iconCode !== "") {
      let iconImg = document.createElement("img");
      iconImg.src = "https://openweathermap.org/img/wn/" + iconCode + "@2x.png";
      iconImg.alt = description;
      currentWeatherDiv.appendChild(iconImg);
    }
  }

  // Muestra una previsión sencilla del clima
  function showForecast(data) {
    if (!forecastWeatherDiv) return;

    forecastWeatherDiv.innerHTML = "";

    if (!data.list || data.list.length === 0) {
      let p = document.createElement("p");
      p.textContent = "No s'ha trobat previsió per aquest destí.";
      forecastWeatherDiv.appendChild(p);
      return;
    }

    let list = document.createElement("ul");
    list.className = "activities-list";

    for (let i = 0; i < data.list.length && i < 5; i++) {
      let item = data.list[i];

      let li = document.createElement("li");

      let date = new Date(item.dt * 1000);
      let temp = item.main && item.main.temp ? item.main.temp : "";
      let description =
        item.weather && item.weather[0] ? item.weather[0].description : "";

      li.textContent =
        date.toLocaleString() + " - " + temp + " °C - " + description;

      list.appendChild(li);
    }

    forecastWeatherDiv.appendChild(list);
  }

  // Hacemos las peticiones a la API del clima
  function fetchWeather(city) {
    clearResults();

    if (weatherFeedback) {
      weatherFeedback.textContent = "Buscant informació del temps...";
      weatherFeedback.className = "form-info";
    }

    // Api para tiempo Actual
    let urlCurrent =
      "https://api.openweathermap.org/data/2.5/weather?q=" +
      encodeURIComponent(city) +
      "&appid=" +
      apiKey +
      "&units=metric&lang=ca";

    // Api para tiempo previsio
    let urlForecast =
      "https://api.openweathermap.org/data/2.5/forecast?q=" +
      encodeURIComponent(city) +
      "&appid=" +
      apiKey +
      "&units=metric&lang=ca";

    fetch(urlCurrent)
      .then(function (response) {
        if (!response.ok)
          throw new Error("No s'ha pogut obtenir el temps actual.");
        return response.json();
      })
      .then(function (data) {
        showCurrentWeather(data);
        return fetch(urlForecast);
      })
      .then(function (response) {
        if (!response.ok) throw new Error("No s'ha pogut obtenir la previsió.");
        return response.json();
      })
      .then(function (forecastData) {
        showForecast(forecastData);
        if (weatherFeedback) {
          weatherFeedback.textContent =
            "Dades meteorològiques carregades correctament.";
          weatherFeedback.className = "form-success";
        }
      })
      .catch(function (error) {
        if (weatherFeedback) {
          weatherFeedback.textContent =
            "Error en carregar el clima: " + error.message;
          weatherFeedback.className = "form-error";
        }
      });
  }

  // Evento al enviar el formulario
  if (weatherForm) {
    weatherForm.addEventListener("submit", function (e) {
      e.preventDefault();

      if (!cityInput) return;

      let city = cityInput.value.trim();

      if (city === "") {
        if (weatherFeedback) {
          weatherFeedback.textContent =
            "Introdueix un destí per buscar el clima.";
          weatherFeedback.className = "form-error";
        }
        return;
      }

      fetchWeather(city);
    });
  }
});
