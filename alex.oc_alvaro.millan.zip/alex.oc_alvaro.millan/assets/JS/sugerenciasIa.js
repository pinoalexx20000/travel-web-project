document.addEventListener("DOMContentLoaded", function () {
  let iaForm = document.getElementById("iaForm");
  let iaInput = document.getElementById("iaInput");
  let iaMessages = document.getElementById("iaMessages");
  let iaFeedback = document.getElementById("iaFeedback");

  // Clave y URL de la API de Gemini
  let geminiApiKey = "AIzaSyCtUR0SpfEL4EzM6dKXx8UI62W-57ysLZA";
  let geminiUrl =
    "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent";

  // Añade un mensaje tanto de Gemini como del Usuario
  function addMessage(text, type) {
    if (!iaMessages) {
      return;
    }

    let messageDiv = document.createElement("div");
    messageDiv.className = "ia-message ia-" + type;

    let p = document.createElement("p");
    p.textContent = text;

    messageDiv.appendChild(p);
    iaMessages.appendChild(messageDiv);

    iaMessages.scrollTop = iaMessages.scrollHeight;
  }

  // Limpia mensajes
  function clearFeedback() {
    if (!iaFeedback) {
      return;
    }
    iaFeedback.textContent = "";
    iaFeedback.className = "";
  }

  // Realiza la petición a la API de Gemini
  function callGemini(promptText) {
    if (!geminiApiKey) {
      if (iaFeedback) {
        iaFeedback.textContent =
          "Configura la teva API Key de Gemini a ia.js abans d'utilitzar aquesta secció.";
        iaFeedback.className = "form-error";
      }
      return;
    }

    let body = {
      contents: [
        {
          role: "user",
          parts: [
            {
              text:
                "Ets un assistent de viatges molt senzill. Només has de proposar destinacions " +
                "o activitats de viatge en forma de llista o text curt.\n\n" +
                "Consulta de l'usuari: " +
                promptText,
            },
          ],
        },
      ],
    };

    return fetch(geminiUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-goog-api-key": geminiApiKey,
      },
      body: JSON.stringify(body),
    }).then(function (response) {
      if (!response.ok) {
        return response.text().then(function (text) {
          throw new Error("Error a Gemini: " + response.status + " - " + text);
        });
      }
      return response.json();
    });
  }

  // Evento al enviar el formulario de IA
  if (iaForm) {
    iaForm.addEventListener("submit", function (e) {
      e.preventDefault();

      clearFeedback();

      if (!iaInput || !iaMessages) {
        return;
      }

      let text = iaInput.value.trim();

      if (text === "") {
        if (iaFeedback) {
          iaFeedback.textContent =
            "Escriu alguna cosa sobre el viatge que vols fer.";
          iaFeedback.className = "form-error";
        }
        return;
      }

      addMessage(text, "user");
      iaInput.value = "";

      addMessage("Pensant suggerències de viatge...", "bot-temp");

      if (iaFeedback) {
        iaFeedback.textContent = "Consultant la IA de Gemini...";
        iaFeedback.className = "form-info";
      }

      callGemini(text)
        .then(function (data) {
          let tempMessages = iaMessages.getElementsByClassName("ia-bot-temp");
          while (tempMessages.length > 0) {
            tempMessages[0].parentNode.removeChild(tempMessages[0]);
          }

          let reply = "";

          if (
            data &&
            data.candidates &&
            data.candidates[0] &&
            data.candidates[0].content &&
            data.candidates[0].content.parts &&
            data.candidates[0].content.parts[0] &&
            data.candidates[0].content.parts[0].text
          ) {
            reply = data.candidates[0].content.parts[0].text;
          } else {
            reply = "No s'ha pogut obtenir una resposta de la IA.";
          }

          addMessage(reply, "bot");

          if (iaFeedback) {
            iaFeedback.textContent = "Suggerències carregades correctament.";
            iaFeedback.className = "form-success";
          }
        })
        .catch(function (error) {
          let tempMessages = iaMessages.getElementsByClassName("ia-bot-temp");
          while (tempMessages.length > 0) {
            tempMessages[0].parentNode.removeChild(tempMessages[0]);
          }

          addMessage(
            "Hi ha hagut un problema amb el sistema de suggerències.",
            "bot"
          );

          if (iaFeedback) {
            iaFeedback.textContent = "Error: " + error.message;
            iaFeedback.className = "form-error";
          }
        });
    });
  }
});
