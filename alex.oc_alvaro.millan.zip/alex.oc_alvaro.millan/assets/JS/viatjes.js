document.addEventListener("DOMContentLoaded", function () {
  // Array principal donde guardaremos los viajes
  let travels = [];

  let travelList = document.getElementById("travelList");

  let travelForm = document.getElementById("travelForm");
  let travelNameInput = document.getElementById("travelName");
  let travelOriginInput = document.getElementById("travelOrigin");
  let travelDestinationInput = document.getElementById("travelDestination");
  let travelStartInput = document.getElementById("travelStart");
  let travelEndInput = document.getElementById("travelEnd");
  let travelFeedback = document.getElementById("travelFeedback");
  let editingTravelIdInput = document.getElementById("editingTravelId");
  let travelEditInfo = document.getElementById("travelEditInfo");

  let activityForm = document.getElementById("activityForm");
  let activityTravelSelect = document.getElementById("activityTravelSelect");
  let activityTitleInput = document.getElementById("activityTitle");
  let activityDescriptionInput = document.getElementById("activityDescription");
  let activityTimeInput = document.getElementById("activityTime");

  // Carga los viajes guardados en localStorage
  function loadTravels() {
    let data = localStorage.getItem("travels");
    if (data) {
      try {
        travels = JSON.parse(data);
      } catch (e) {
        travels = [];
      }
    } else {
      travels = [];
    }
  }
  // Guarda los viajes actuales en localStorage
  function saveTravels() {
    localStorage.setItem("travels", JSON.stringify(travels));
  }
  // Limpia el formulario
  function clearTravelForm() {
    if (travelNameInput) travelNameInput.value = "";
    if (travelOriginInput) travelOriginInput.value = "";
    if (travelDestinationInput) travelDestinationInput.value = "";
    if (travelStartInput) travelStartInput.value = "";
    if (travelEndInput) travelEndInput.value = "";
    if (editingTravelIdInput) editingTravelIdInput.value = "";
    if (travelEditInfo) {
      travelEditInfo.textContent = "";
      travelEditInfo.className = "";
    }
  }
  // Actualizaremos el select para escoger a qué viaje se le añade una actividad
  function updateTravelSelect() {
    if (!activityTravelSelect) return;

    activityTravelSelect.innerHTML = "";

    if (travels.length === 0) {
      let option = document.createElement("option");
      option.value = "";
      option.textContent = "No hi ha viatges disponibles";
      activityTravelSelect.appendChild(option);
      return;
    }

    for (let i = 0; i < travels.length; i++) {
      let travel = travels[i];
      let option = document.createElement("option");
      option.value = travel.id;
      option.textContent = travel.name;
      activityTravelSelect.appendChild(option);
    }
  }
  // Elimina un viaje por id
  function deleteTravel(travelId) {
    let newTravels = [];
    for (let i = 0; i < travels.length; i++) {
      if (travels[i].id !== travelId) {
        newTravels.push(travels[i]);
      }
    }
    travels = newTravels;
    saveTravels();
    renderTravels();
    updateTravelSelect();
    clearTravelForm();
  }
  // Elimina una actividad concreta de un viaje
  function deleteActivity(travelId, activityIndex) {
    for (let i = 0; i < travels.length; i++) {
      if (travels[i].id === travelId) {
        if (
          travels[i].activities &&
          travels[i].activities.length > activityIndex
        ) {
          travels[i].activities.splice(activityIndex, 1);
        }
      }
    }
    saveTravels();
    renderTravels();
  }
  // Poner los datos del viaje en el formulario para editarlo
  function startEditTravel(travelId) {
    let travelToEdit = null;
    for (let i = 0; i < travels.length; i++) {
      if (travels[i].id === travelId) {
        travelToEdit = travels[i];
      }
    }

    if (!travelToEdit) {
      return;
    }

    if (travelNameInput) travelNameInput.value = travelToEdit.name;
    if (travelOriginInput) travelOriginInput.value = travelToEdit.origin;
    if (travelDestinationInput)
      travelDestinationInput.value = travelToEdit.destination;
    if (travelStartInput) travelStartInput.value = travelToEdit.startDate;
    if (travelEndInput) travelEndInput.value = travelToEdit.endDate;

    if (editingTravelIdInput)
      editingTravelIdInput.value = String(travelToEdit.id);

    if (travelEditInfo) {
      travelEditInfo.textContent = "Editant viatge: " + travelToEdit.name;
      travelEditInfo.className = "form-info";
    }

    if (travelFeedback) {
      travelFeedback.textContent = "";
      travelFeedback.className = "";
    }
  }
  // Muestra todos los viajes guardados en pantalla
  function renderTravels() {
    if (!travelList) return;

    travelList.innerHTML = "";

    // Si no hay viajes, muestra un mensaje
    if (travels.length === 0) {
      let empty = document.createElement("p");
      empty.textContent = "No hi ha viatges guardats encara.";
      travelList.appendChild(empty);
      return;
    }

    for (let i = 0; i < travels.length; i++) {
      let travel = travels[i];

      // Tarjeta del viaje
      let card = document.createElement("div");
      card.className = "viatge-card";

      let title = document.createElement("h3");
      title.textContent = travel.name;
      card.appendChild(title);

      let info = document.createElement("p");
      info.textContent =
        "Origen: " +
        travel.origin +
        " | Destí: " +
        travel.destination +
        " | " +
        travel.startDate +
        " - " +
        travel.endDate;
      card.appendChild(info);

      // Título de las actividades
      let activitiesTitle = document.createElement("p");
      activitiesTitle.style.fontWeight = "bold";
      activitiesTitle.textContent = "Activitats:";
      card.appendChild(activitiesTitle);

      let activitiesList = document.createElement("ul");
      activitiesList.className = "activities-list";

      // Lista de actividades del viaje
      if (travel.activities && travel.activities.length > 0) {
        for (let j = 0; j < travel.activities.length; j++) {
          let activity = travel.activities[j];
          let li = document.createElement("li");

          let text = activity.title;
          if (activity.time && activity.time !== "") {
            text += " (" + activity.time + ")";
          }
          if (activity.description && activity.description !== "") {
            text += " - " + activity.description;
          }

          let spanText = document.createElement("span");
          spanText.textContent = text + " ";
          li.appendChild(spanText);

          // Botón para eliminar la actividad
          let deleteButton = document.createElement("button");
          deleteButton.textContent = "Eliminar";
          deleteButton.className = "delete-activity-btn";
          deleteButton.addEventListener("click", function () {
            deleteActivity(travel.id, j);
          });

          li.appendChild(deleteButton);
          activitiesList.appendChild(li);
        }
      } else {
        let noActivity = document.createElement("li");
        noActivity.textContent = "Encara no hi ha activitats.";
        activitiesList.appendChild(noActivity);
      }

      card.appendChild(activitiesList);
      // Botones de acciones del viaje
      let actions = document.createElement("div");
      actions.className = "viatge-actions";

      let editTravelButton = document.createElement("button");
      editTravelButton.textContent = "Editar viatge";
      editTravelButton.addEventListener("click", function () {
        startEditTravel(travel.id);
      });

      let deleteTravelButton = document.createElement("button");
      deleteTravelButton.textContent = "Eliminar viatge";
      deleteTravelButton.className = "delete";
      deleteTravelButton.addEventListener("click", function () {
        deleteTravel(travel.id);
      });

      actions.appendChild(editTravelButton);
      actions.appendChild(deleteTravelButton);
      card.appendChild(actions);

      travelList.appendChild(card);
    }
  }
  // Evento al enviar el formulario de viajes
  if (travelForm) {
    travelForm.addEventListener("submit", function (e) {
      e.preventDefault();

      if (travelFeedback) {
        travelFeedback.textContent = "";
        travelFeedback.className = "";
      }
      // Se comprueba que los inputs existen
      if (
        !travelNameInput ||
        !travelOriginInput ||
        !travelDestinationInput ||
        !travelStartInput ||
        !travelEndInput
      ) {
        return;
      }

      let name = travelNameInput.value.trim();
      let origin = travelOriginInput.value.trim();
      let destination = travelDestinationInput.value.trim();
      let startDate = travelStartInput.value;
      let endDate = travelEndInput.value;

      if (
        name === "" ||
        origin === "" ||
        destination === "" ||
        startDate === "" ||
        endDate === ""
      ) {
        if (travelFeedback) {
          travelFeedback.textContent = "Omple tots els camps del viatge.";
          travelFeedback.className = "form-error";
        }
        return;
      }
      // Validamos las fechas
      if (startDate > endDate) {
        if (travelFeedback) {
          travelFeedback.textContent =
            "La data d'inici ha de ser anterior o igual a la data de final.";
          travelFeedback.className = "form-error";
        }
        return;
      }

      let editingId = editingTravelIdInput ? editingTravelIdInput.value : "";
      // Entramos en la opción de si se está editando un viaje
      if (editingId !== "") {
        for (let i = 0; i < travels.length; i++) {
          if (String(travels[i].id) === String(editingId)) {
            travels[i].name = name;
            travels[i].origin = origin;
            travels[i].destination = destination;
            travels[i].startDate = startDate;
            travels[i].endDate = endDate;
          }
        }

        saveTravels();
        renderTravels();
        updateTravelSelect();
        clearTravelForm();

        if (travelFeedback) {
          travelFeedback.textContent = "Viatge actualitzat correctament.";
          travelFeedback.className = "form-success";
        }
      } else {
        // Sino se edita, entramos en el codigo de crear un nuevo viaje
        let travel = {
          id: Date.now(),
          name: name,
          origin: origin,
          destination: destination,
          startDate: startDate,
          endDate: endDate,
          activities: [],
        };

        travels.push(travel);
        saveTravels();
        renderTravels();
        updateTravelSelect();
        clearTravelForm();

        if (travelFeedback) {
          travelFeedback.textContent = "Viatge guardat correctament.";
          travelFeedback.className = "form-success";
        }
      }
    });
  }
  // Evento al añadir una actividad
  if (activityForm) {
    activityForm.addEventListener("submit", function (e) {
      e.preventDefault();

      if (!activityTravelSelect || !activityTitleInput) {
        return;
      }

      let travelId = activityTravelSelect.value;
      let title = activityTitleInput.value.trim();
      let description = "";
      let time = "";

      if (activityDescriptionInput) {
        description = activityDescriptionInput.value.trim();
      }
      if (activityTimeInput) {
        time = activityTimeInput.value.trim();
      }

      if (travelId === "" || title === "") {
        return;
      }
      // Añadimos la actividad al viaje seleccionado
      for (let i = 0; i < travels.length; i++) {
        if (String(travels[i].id) === String(travelId)) {
          if (!travels[i].activities) {
            travels[i].activities = [];
          }

          travels[i].activities.push({
            title: title,
            description: description,
            time: time,
          });
        }
      }

      saveTravels();
      renderTravels();

      activityTitleInput.value = "";
      if (activityDescriptionInput) {
        activityDescriptionInput.value = "";
      }
      if (activityTimeInput) {
        activityTimeInput.value = "";
      }
    });
  }
  // Cargamos datos iniciales de datos
  loadTravels();
  renderTravels();
  updateTravelSelect();
});
