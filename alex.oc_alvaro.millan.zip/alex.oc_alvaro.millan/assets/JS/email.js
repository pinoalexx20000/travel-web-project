document.addEventListener("DOMContentLoaded", function () {
  let contactForm = document.getElementById("contact-form");
  if (!contactForm) {
    return;
  }

  // Inputs del formulario
  let nameInput = document.getElementById("name");
  let surnameInput = document.getElementById("surname");
  let emailInput = document.getElementById("email");
  let messageInput = document.getElementById("message");

  // Elementos para mostrar errores y mensajes
  let nameError = document.getElementById("nameError");
  let emailError = document.getElementById("emailError");
  let messageError = document.getElementById("messageError");
  let formFeedback = document.getElementById("formFeedback");
  let submitButton = contactForm.querySelector('input[type="submit"]');

  // Datos necesarios para EmailJS
  let serviceId = "service_n7k9puq";
  let templateIdTeam = "template_nxio61u";
  let templateIdClient = "template_05wuvce";
  let publicKey = "f-ZIdvh7cMhyk5l-s";
  let apiUrl = "https://api.emailjs.com/api/v1.0/email/send";

  let teamEmail = "pinoalexx2000@gmail.com";

  // Si dá error, limpia las varibles
  function clearErrors() {
    nameError.textContent = "";
    emailError.textContent = "";
    messageError.textContent = "";
    formFeedback.textContent = "";
    formFeedback.className = "";
  }

  // Comprueba que los campos obligatorios no estén vacíos
  function validateForm() {
    let hasError = false;

    if (nameInput.value.trim() === "") {
      nameError.textContent = "Introdueix el teu nom.";
      hasError = true;
    }

    if (emailInput.value.trim() === "") {
      emailError.textContent = "Introdueix el teu email.";
      hasError = true;
    }

    if (messageInput.value.trim() === "") {
      messageError.textContent = "Escriu un missatge.";
      hasError = true;
    }

    if (hasError) {
      formFeedback.textContent = "Revisa els errors abans d'enviar.";
      formFeedback.className = "form-error";
    }

    return !hasError;
  }

  // Construye el cuerpo que se envía a EmailJS ( muy importante para que en la plantilla en el mismo EmailJS no de problemas)
  function buildBody(templateId, toEmail) {
    return {
      service_id: serviceId,
      template_id: templateId,
      user_id: publicKey,
      template_params: {
        to_email: toEmail,
        from_name: nameInput.value.trim() + " " + surnameInput.value.trim(),
        from_email: emailInput.value.trim(),
        message: messageInput.value.trim(),
      },
    };
  }

  // Envía el correo usando fetch y si no hay respues dará error
  function sendEmail(body) {
    return fetch(apiUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(body),
    }).then(function (response) {
      if (!response.ok) {
        return response.text().then(function (text) {
          throw new Error("EmailJS: " + response.status + " - " + text);
        });
      }
      return response;
    });
  }

  // Evento al enviar el formulario
  contactForm.addEventListener("submit", function (e) {
    e.preventDefault();

    clearErrors();

    if (!validateForm()) {
      return;
    }

    submitButton.disabled = true;
    submitButton.value = "Enviant...";
    formFeedback.textContent = "Enviant missatge...";
    formFeedback.className = "form-info";

    let bodyTeam = buildBody(templateIdTeam, teamEmail);
    let bodyClient = buildBody(templateIdClient, emailInput.value.trim());

    sendEmail(bodyTeam)
      .then(function () {
        return sendEmail(bodyClient);
      })
      .then(function () {
        contactForm.reset();
        formFeedback.textContent =
          "Missatge enviat correctament. Hem enviat una còpia al teu correu.";
        formFeedback.className = "form-success";
      })
      .catch(function (error) {
        formFeedback.textContent = "Error en l'enviament: " + error.message;
        formFeedback.className = "form-error";
      })
      .finally(function () {
        submitButton.disabled = false;
        submitButton.value = "Enviar";
      });
  });
});
